const Opts = (typeof modmanager !== 'undefined' && modmanager.registerAndGetModOptions) ? modmanager.registerAndGetModOptions(
    {
        modId: 'night-mode',
        title: 'Night Mode',
    },
    {
        general: {
            settings: {
                title: 'General Settings',
                tabIcon: 'general',
            },
            headers: {
                'Gameplay Options': {
                    timeRatio: {
                        type: 'OBJECT_SLIDER',
                        init: 1,
                        min: 0.1,
                        max: 10,
                        step: 0.1,
                        fill: true,
                        showPercentage: false,
                        name: 'Time Ratio',
                        description: 'Adjusts how fast time passes. (Default: 1x)',
                        customNumberDisplay(index) {
                            const num = this.min + (this.step * index);
                            return num.toFixed(1) + 'x';
                        }
                    },
                    lockdown: {
                        type: 'CHECKBOX',
                        init: true,
                        name: 'Night Lockdown',
                        description: 'Prevents fast travel during the night.',
                    },
                    npcRest: {
                        type: 'CHECKBOX',
                        init: true,
                        name: 'NPC Rest Protocol',
                        description: 'Generic NPCs will respond with Zzz... at night.',
                    }
                }
            }
        }
    }
) : {
    timeRatio: 1,
    lockdown: true,
    npcRest: true
};

ig.module('night-mode')
    .requires(
        'impact.base.game',
        'game.feature.model.game-model',
        'impact.feature.light.light',
        'game.feature.weather.weather',
        'game.feature.gui.base.text',
        'impact.feature.gui.gui',
        'game.feature.npc.entities.npc'
    )
    .defines(() => {
        const nm = {
            enabled: true,
            _gameTime: 0.5,
            _currentPhase: 'day',
            _overlayAlpha: 0,
            _darknessTarget: 0.75
        };

        // --- UI Indicator ---
        let PhaseIndicator = ig.GuiElementBase.extend({
            transitions: {
                HIDDEN: { state: { alpha: 0, offsetY: -20 }, time: 0.2, timeFunction: KEY_SPLINES.EASE_OUT },
                DEFAULT: { state: { alpha: 1, offsetY: 0 }, time: 0.2, timeFunction: KEY_SPLINES.EASE_IN }
            },
            gfx: new ig.Image('assets/mods/night-mode/assets/icon.png'),
            init: function(phase) {
                this.parent();
                this.setAlign(ig.GUI_ALIGN.X_CENTER, ig.GUI_ALIGN.Y_TOP);
                this.setPos(0, 10);
                
                let phaseText = "Sunrise";
                if (phase === 'day') phaseText = "Daytime";
                if (phase === 'sunset') phaseText = "Sunset";
                if (phase === 'night') phaseText = "Nightfall";

                this.text = new sc.TextGui(phaseText, { font: sc.fontsystem.font });
                this.text.setPos(20, 2);
                this.addChildGui(this.text);
                
                this.setSize(20 + this.text.hook.size.x, 20);
                this.doStateTransition('HIDDEN', true);
                
                this.timer = 3;
                this.doStateTransition('DEFAULT');
            },
            update: function() {
                this.parent();
                if (this.timer > 0) {
                    this.timer -= ig.system.actualTick;
                    if (this.timer <= 0) {
                        this.doStateTransition('HIDDEN');
                        setTimeout(() => this.remove(), 500);
                    }
                }
            },
            updateDrawables: function(src) {
                src.addGfx(this.gfx, 0, 0, 0, 0, 16, 16);
            }
        });

        function triggerHammerDrop(phase) {
            if (window.console && console.log) console.log('[Night Mode] Phase changed to: ' + phase);
            if (ig.gui) {
                ig.gui.addGuiElement(new PhaseIndicator(phase));
            }
        }

        // --- Persistent Clock HUD ---
        let ClockGui = ig.GuiElementBase.extend({
            init: function() {
                this.parent();
                this.setAlign(ig.GUI_ALIGN.X_RIGHT, ig.GUI_ALIGN.Y_TOP);
                this.setPos(5, 5);
                this.hook.zIndex = 999999;
                
                this.box = new sc.WindowGui(40, 20);
                this.addChildGui(this.box);
                
                this.text = new sc.TextGui("", { font: sc.fontsystem.smallFont });
                this.text.setAlign(ig.GUI_ALIGN.X_CENTER, ig.GUI_ALIGN.Y_CENTER);
                this.addChildGui(this.text);
            },
            update: function() {
                this.parent();
                
                if (!nm.enabled || sc.model.isMenu() || sc.model.isTitle() || sc.model.isCutscene()) {
                    this.hook.localAlpha = 0;
                    return;
                } else {
                    this.hook.localAlpha = 1;
                }
                
                const time = (nm._gameTime * 24 + 8.4) % 24;
                const totalMinutes = Math.floor(time * 60);
                const hours = Math.floor(totalMinutes / 60).toString().padStart(2, '0');
                const minutes = (totalMinutes % 60).toString().padStart(2, '0');
                
                this.text.setText(`${hours}:${minutes}`);
                
                const w = this.text.hook.size.x + 8;
                const h = this.text.hook.size.y + 6;
                this.box.setSize(w, h);
                this.setSize(w, h);
            }
        });

        let clockInstance = null;

        // --- Core Time Engine ---
        function updateTimeEngine(dt) {
            if (!nm.enabled) return;
            const speed = (Opts.timeRatio > 0) ? (1 / (Opts.timeRatio * 60)) : (1 / 1200);
            nm._gameTime += speed * dt;
            if (nm._gameTime > 1) nm._gameTime -= 1;

            let phase = 'day';
            let alpha = 0;
            
            if (nm._gameTime > 0.40 && nm._gameTime < 0.45) {
                phase = 'sunset';
                alpha = ((nm._gameTime - 0.40) / 0.05) * nm._darknessTarget;
            }
            else if (nm._gameTime >= 0.45 && nm._gameTime < 0.90) {
                phase = 'night';
                alpha = nm._darknessTarget;
            }
            else if (nm._gameTime >= 0.90 && nm._gameTime < 0.95) {
                phase = 'sunrise';
                alpha = nm._darknessTarget - (((nm._gameTime - 0.90) / 0.05) * nm._darknessTarget);
            }

            nm._overlayAlpha = alpha;

            if (phase !== nm._currentPhase) {
                nm._currentPhase = phase;
                triggerHammerDrop(phase);
            }
        }

        // --- Hooking Game Update for Time ---
        ig.Game.inject({
            update: function() {
                this.parent();
                const dt = ig.system.tick || (1 / 60);
                updateTimeEngine(dt);

                if (ig.gui && (!clockInstance || ig.gui.guiHooks.indexOf(clockInstance.hook) === -1)) {
                    if (!clockInstance) clockInstance = new ClockGui();
                    ig.gui.addGuiElement(clockInstance);
                }
            }
        });

        // --- Hooking Weather for Atmosphere ---
        ig.Weather.inject({
            onDeferredUpdate: function() {
                this.parent();

                if (!nm.enabled) return;
                
                // Override Darkness seamlessly
                if (ig.light) {
                    const currentMapDarkness = this.lightMapDarkness ? this.lightMapDarkness.last : 0;
                    ig.light.lightMapDarkness = Math.max(currentMapDarkness, nm._overlayAlpha);
                }

                // Add Sapphire Ridge Fog during sunset/night/sunrise
                if (nm._currentPhase !== 'day' && this.fog) {
                    const fogTarget = (nm._overlayAlpha / nm._darknessTarget) * 0.8;
                    this.fog.alpha = Math.max(this.fog.alpha || 0, fogTarget);
                    
                    if (this.fog.vel) {
                        if (this.fog.vel.x === 0 && this.fog.vel.y === 0) {
                            this.fog.vel.x = 30;
                            this.fog.vel.y = 10;
                        }
                    }
                }
            }
        });

        // --- Gameplay Hooks ---
        sc.GameModel.inject({
            isTeleportBlocked: function() {
                if (nm.enabled && Opts.lockdown && nm._currentPhase === 'night') {
                    return true;
                }
                return this.parent();
            }
        });

        ig.ENTITY.Npc.inject({
            onInteraction: function() {
                if (nm.enabled && Opts.npcRest && nm._currentPhase === 'night') {
                    if (sc.BUTTON_SOUND && sc.BUTTON_SOUND.denied) sc.BUTTON_SOUND.denied.play();
                    return;
                }
                this.parent();
            }
        });

        window.NightMode = {
            getPhase: () => nm._currentPhase,
            getAlpha: () => nm._overlayAlpha,
            getTime: () => nm._gameTime
        };
    });
