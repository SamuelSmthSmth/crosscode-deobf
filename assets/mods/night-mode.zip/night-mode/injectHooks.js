const fs = require('fs');
let js = fs.readFileSync('assets/mods/night-mode/night-mode.js', 'utf8');

const hooksCode = `
    // ============================================================
    // GAMEPLAY HOOKS (Phase 4)
    // ============================================================
    function hijackGameplayHooks() {
        if (!window.ig || !ig.ENTITY || !ig.ENTITY.NPC || !ig.ENTITY.NPC.prototype.onInteraction) {
            setTimeout(hijackGameplayHooks, 100);
            return;
        }

        // 1. NPC Rest
        const oldOnInteraction = ig.ENTITY.NPC.prototype.onInteraction;
        ig.ENTITY.NPC.prototype.onInteraction = function() {
            if (nm.enabled && Opts.npcRest && nm._currentPhase === 'night') {
                if (sc.BUTTON_SOUND && sc.BUTTON_SOUND.denied) sc.BUTTON_SOUND.denied.play();
                // Spawn a quick Zzz text
                if (ig.game && ig.game.spawnEntity && ig.ENTITY.CombatText) {
                    ig.game.spawnEntity(ig.ENTITY.CombatText, this.coll.pos.x, this.coll.pos.y, this.coll.pos.z + this.coll.size.z + 10, {text: "Zzz...", color: "WHITE"});
                }
                return false; 
            }
            return oldOnInteraction.call(this);
        };

        // 2. Lockdown
        if (sc.GameModel && sc.GameModel.prototype.isTeleportBlocked) {
            const oldIsTeleportBlocked = sc.GameModel.prototype.isTeleportBlocked;
            sc.GameModel.prototype.isTeleportBlocked = function() {
                if (nm.enabled && Opts.lockdown && nm._currentPhase === 'night') {
                    return true;
                }
                return oldIsTeleportBlocked.call(this);
            };
        }
        
        if (window.console && console.log) console.log('[Night Mode] Gameplay Hooks Injected.');
    }

    // ============================================================
    // HAMMER DROP UI (Phase 3)
    // ============================================================
    let phaseIndicatorClass = null;
    function initPhaseIndicator() {
        if (!window.sc || !sc.TextGui) {
            setTimeout(initPhaseIndicator, 100);
            return;
        }
        phaseIndicatorClass = ig.GuiElementBase.extend({
            transitions: {
                HIDDEN: { state: { alpha: 0, offsetY: -20 }, time: 0.2, timeFunction: KEY_SPLINES.EASE_OUT },
                DEFAULT: { state: { alpha: 1, offsetY: 0 }, time: 0.2, timeFunction: KEY_SPLINES.EASE_IN }
            },
            gfx: new ig.Image('assets/mods/night-mode/night-mode-icon.png'),
            text: null,
            timer: 0,
            init: function(phase) {
                this.parent();
                this.setAlign(ig.GUI_ALIGN.X_CENTER, ig.GUI_ALIGN.Y_TOP);
                this.setPos(0, 40);
                
                let phaseText = "Sunrise";
                if (phase === 'day') phaseText = "Daytime";
                if (phase === 'sunset') phaseText = "Sunset";
                if (phase === 'night') phaseText = "Nightfall";

                this.text = new sc.TextGui(phaseText, { font: sc.fontsystem.font });
                this.text.setAlign(ig.GUI_ALIGN.X_CENTER, ig.GUI_ALIGN.Y_CENTER);
                this.text.setPos(12, 0); // Offset for icon
                
                this.setSize(this.text.hook.size.x + 36, 24);
                this.addChildGui(this.text);
                
                this.doStateTransition("HIDDEN", true);
                this.doStateTransition("DEFAULT", false);
                this.timer = 3.0;
            },
            update: function() {
                if (this.timer > 0) {
                    this.timer -= ig.system.tick;
                    if (this.timer <= 0) {
                        this.doStateTransition("HIDDEN", false);
                    }
                } else if (this.hook.currentStateName === "HIDDEN" && this.hook.transitions.HIDDEN.state.alpha === this.hook.currentState.alpha) {
                    this.remove();
                }
            },
            updateDrawables: function(src) {
                // Background dark box
                src.addColor('rgba(0,0,0,0.6)', 0, 0, this.hook.size.x, this.hook.size.y);
                // Icon
                src.addGfx(this.gfx, 4, 4, 0, 0, 16, 16);
            }
        });
    }
`;

// Insert right before hijackDraw definition
js = js.replace(/    function hijackDraw/, hooksCode + '\n    function hijackDraw');

// Update triggerHammerDrop to use it
const newHammerDrop = `
    function triggerHammerDrop(phase) {
        if (window.console && console.log) console.log('[Night Mode] Phase changed to: ' + phase);
        if (ig.gui && phaseIndicatorClass) {
            const indicator = new phaseIndicatorClass(phase);
            ig.gui.addGuiElement(indicator);
        }
    }
`;
js = js.replace(/    function triggerHammerDrop\(phase\) \{[\s\S]*?\}/, newHammerDrop);

// Insert init calls at the bottom, right before `hijackDraw();`
const initCalls = `
    initPhaseIndicator();
    hijackGameplayHooks();
`;
js = js.replace(/    hijackDraw\(\);/, initCalls + '\n    hijackDraw();');

fs.writeFileSync('assets/mods/night-mode/night-mode.js', js);
console.log('Hooks injected successfully.');
