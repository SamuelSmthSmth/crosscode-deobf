const fs = require('fs');

const OLD_FILE = 'assets/mods/night-mode/night-mode.js';
const NEW_FILE = 'assets/mods/night-mode/night-mode.js';

let js = fs.readFileSync(OLD_FILE, 'utf8');

console.log('Script loaded.');
