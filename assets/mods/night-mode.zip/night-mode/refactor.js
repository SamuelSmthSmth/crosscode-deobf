const fs = require('fs');
let js = fs.readFileSync('assets/mods/night-mode/night-mode.js', 'utf8');

// 1. Inject modmanager.registerAndGetModOptions at the very top (after IIFE start)
const optionsCode = `
    const Opts = (typeof modmanager !== 'undefined' && modmanager.registerAndGetModOptions) ? modmanager.registerAndGetModOptions(
        { modId: 'night-mode', title: 'Night Mode' },
        {
            general: {
                settings: { title: 'Settings', tabIcon: 'general' },
                headers: {
                    'Visuals & Atmosphere': {
                        timeRatio: {
                            type: 'OBJECT_SLIDER', init: 20, min: 1, max: 60, step: 1, fill: true, showPercentage: false,
                            name: 'Day Cycle Length (Mins)', description: 'How many real-world minutes a full day lasts.'
                        },
                        tiltShift: {
                            type: 'CHECKBOX', init: true, name: 'Tilt-Shift Blur', description: 'Enables depth-of-field blur during dusk and night.'
                        }
                    },
                    'Gameplay Rules': {
                        lockdown: {
                            type: 'CHECKBOX', init: false, name: 'Night Lockdown', description: 'Disables fast travel map teleportation during the night phase.'
                        },
                        npcRest: {
                            type: 'CHECKBOX', init: false, name: 'NPC Night Protocols', description: 'Generic NPCs go to sleep during the night.'
                        }
                    }
                }
            }
        }
    ) : { timeRatio: 20, tiltShift: true, lockdown: false, npcRest: false };
`;

// Insert after the header
js = js.replace(/const STORAGE_KEY = 'nightModeSettings';/, optionsCode + '\n    const STORAGE_KEY = \'nightModeSettings\';');

// 2. Remove old `nm` object except for internal state.
const nmCode = `
    const nm = {
        enabled: true,
        _gameTime: 0.5,
        _currentPhase: 'day',
        _blurStrength: 0,
        _overlayAlpha: 0,
        _blurDirty: true,

        // Hardcoded visual presets
        lanternEnabled: true, lanternRadius: 80, lanternSoftness: 0.55,
        glowEnabled: true, glowStrength: 0.35,
        clockEnabled: true, clockOpacity: 0.85, clockAutoHideCombat: true, clockX: -1, clockY: -1,
        blurSpread: 0.28, blurScale: 0.5,
        dayBlur: 0, sunriseBlur: 2, sunsetBlur: 3, nightBlur: 5,
    };
`;
// Replace the old `const nm = { ... };` entirely.
js = js.replace(/const nm = \{[\s\S]*?\};\n/, nmCode);

// 3. Remove sanitizeSettings, saveSettings, loadSettings, getSerializableSettings
js = js.replace(/function getSerializableSettings\(\) \{[\s\S]*?\}\n/g, '');
js = js.replace(/function sanitizeSettings\(\) \{[\s\S]*?\}\n/g, '');
js = js.replace(/function saveSettings\(\) \{[\s\S]*?\}\n/g, '');
js = js.replace(/function loadSettings\(\) \{[\s\S]*?\}\n/g, '');

// 4. Update TimeEngine to use Bezier curves.
const newTimeEngine = `
    // Simple Bezier easing for time
    function easeInOutSine(x) { return -(Math.cos(Math.PI * x) - 1) / 2; }
    
    function updateTimeEngine(dt) {
        if (!nm.enabled) return;
        const speed = (Opts.timeRatio > 0) ? (1 / (Opts.timeRatio * 60)) : (1 / 1200);
        nm._gameTime += dt * speed;
        if (nm._gameTime > 1.0) nm._gameTime -= 1.0;

        let phase = 'day';
        if (nm._gameTime >= 0.22 && nm._gameTime < 0.28) phase = 'sunset';
        else if (nm._gameTime >= 0.28 && nm._gameTime < 0.72) phase = 'night';
        else if (nm._gameTime >= 0.72 && nm._gameTime < 0.78) phase = 'sunrise';

        if (phase !== nm._currentPhase) {
            nm._currentPhase = phase;
            triggerHammerDrop(phase);
        }

        // Calculate visual targets based on phase
        let targetAlpha = 0;
        let targetBlur  = nm.dayBlur;

        if (phase === 'sunset') {
            const p = (nm._gameTime - 0.22) / 0.06;
            const e = easeInOutSine(p);
            targetAlpha = e * 0.65;
            targetBlur  = nm.dayBlur + (nm.sunsetBlur - nm.dayBlur) * e;
        } else if (phase === 'night') {
            targetAlpha = 0.65;
            targetBlur  = nm.nightBlur;
        } else if (phase === 'sunrise') {
            const p = (nm._gameTime - 0.72) / 0.06;
            const e = easeInOutSine(p);
            targetAlpha = 0.65 * (1 - e);
            targetBlur  = nm.nightBlur + (nm.sunriseBlur - nm.nightBlur) * e;
        }

        nm._overlayAlpha = nm._overlayAlpha + (targetAlpha - nm._overlayAlpha) * dt * 2.0;
        nm._blurStrength = nm._blurStrength + (targetBlur - nm._blurStrength) * dt * 1.5;
    }
`;
js = js.replace(/function updateTimeEngine\(dt\) \{[\s\S]*?(?=\n\n    \/\/ =================)/, newTimeEngine);

// 5. Rewrite hijackDraw to hook both ig.Game and ig.Light
const newHijackDraw = `
    function hijackDraw() {
        if (!window.ig || !ig.Game || !ig.Game.prototype.draw) {
            setTimeout(hijackDraw, 100); return;
        }
        if (ig.Game.prototype.draw.__nmPatched) return;

        // 1. Hook Game.draw for Time Engine and Clock
        const oldDraw = ig.Game.prototype.draw;
        ig.Game.prototype.draw = function () {
            oldDraw.call(this);
            if (!nm.enabled) return;
            
            const dt = this.deltaTime || (1 / 60);
            updateTimeEngine(dt);
            
            if (ig.system && ig.system.context) {
                drawCelestialClock(ig.system.context, ig.system.realWidth, ig.system.realHeight, isCombatActive());
            }
        };
        ig.Game.prototype.draw.__nmPatched = true;

        // 2. Hook Light.onMidDraw for Atmospheric Overlays
        if (ig.Light && ig.Light.prototype.onMidDraw) {
            const oldLightDraw = ig.Light.prototype.onMidDraw;
            ig.Light.prototype.onMidDraw = function() {
                const ctx = ig.system.context;
                const src = ig.system.canvas;
                const w = ig.system.realWidth;
                const h = ig.system.realHeight;

                if (nm.enabled) {
                    if (Opts.tiltShift) {
                        drawEdgeBlur(ctx, src, w, h);
                        drawBloom(ctx, src, w, h);
                    }
                    if (nm._overlayAlpha > 0.002) {
                        drawDarkOverlay(ctx, w, h);
                    }
                }
                oldLightDraw.call(this);
            };
        }
    }
`;
js = js.replace(/function hijackDraw\(\) \{[\s\S]*?(?=\n\n    \/\/ =================)/, newHijackDraw);

// 6. Rewrite drawDarkOverlay for Gradients
const newDrawDark = `
    function drawDarkOverlay(ctx, w, h) {
        if (nm._overlayAlpha < 0.002) return;
        ctx.save();
        ctx.setTransform(1, 0, 0, 1, 0, 0);
        const alpha = nm._overlayAlpha;

        // Atmospheric Gradient
        const grad = ctx.createLinearGradient(0, 0, 0, h);
        if (nm._currentPhase === 'sunset' || nm._currentPhase === 'sunrise') {
            // Dusk/Dawn: Deep Orange to Twilight Blue
            grad.addColorStop(0, \`rgba(15, 20, 40, \${alpha})\`);
            grad.addColorStop(1, \`rgba(200, 80, 20, \${alpha * 0.8})\`);
        } else {
            // Deep Night
            grad.addColorStop(0, \`rgba(5, 5, 15, \${alpha})\`);
            grad.addColorStop(1, \`rgba(15, 20, 30, \${alpha})\`);
        }

        const playerPos = nm.lanternEnabled ? getPlayerScreenPos(w, h) : null;
        if (nm.lanternEnabled && playerPos) {
            const tmp = document.createElement('canvas');
            tmp.width = w; tmp.height = h;
            const tmpCtx = tmp.getContext('2d');

            tmpCtx.fillStyle = grad;
            tmpCtx.fillRect(0, 0, w, h);

            const r = nm.lanternRadius;
            const radGrad = tmpCtx.createRadialGradient(playerPos.x, playerPos.y, 0, playerPos.x, playerPos.y, r);
            const corePct = clamp(1.0 - nm.lanternSoftness, 0, 0.95);
            radGrad.addColorStop(0, 'rgba(0,0,0,1)');
            if (corePct > 0.01) radGrad.addColorStop(corePct, 'rgba(0,0,0,1)');
            radGrad.addColorStop(corePct + (1 - corePct) * 0.33, 'rgba(0,0,0,0.65)');
            radGrad.addColorStop(corePct + (1 - corePct) * 0.66, 'rgba(0,0,0,0.25)');
            radGrad.addColorStop(1, 'rgba(0,0,0,0)');

            tmpCtx.globalCompositeOperation = 'destination-out';
            tmpCtx.fillStyle = radGrad;
            tmpCtx.fillRect(0, 0, w, h);

            ctx.globalAlpha = 1.0;
            ctx.drawImage(tmp, 0, 0);
        } else {
            ctx.fillStyle = grad;
            ctx.fillRect(0, 0, w, h);
        }

        ctx.restore();
    }
`;
js = js.replace(/function drawDarkOverlay\(ctx, w, h\) \{[\s\S]*?(?=\n    function drawCelestialClock)/, newDrawDark);

// 7. Add triggerHammerDrop function stub
js += `
    function triggerHammerDrop(phase) {
        // TODO: Implement Hammer Drop UI animation
        if (window.console && console.log) console.log('[Night Mode] Phase changed to: ' + phase);
    }
`;

fs.writeFileSync('assets/mods/night-mode/night-mode.js', js);
console.log('Refactor complete.');
